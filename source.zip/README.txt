==================================================
Property of [Team Enigma]

Created on: 24.11.2017

Source code remain the property of the developers: 
- Florian Akos Szabo
- Ijlal Niazi
- Jose Perdomo
- Xhesika Ruci
- Kristian Kouros
==================================================

