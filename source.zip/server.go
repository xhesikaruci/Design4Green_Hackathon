package main

import (
	"fmt"
	"net/http"
	"net/url"
	"log"
	"io/ioutil"
	"database/sql"
  _ "github.com/mattn/go-sqlite3"
	"html/template"
	"strings"
)

type Doctor struct {
	Id template.HTML
	Firstname string
	Lastname string
	Email template.HTML
	Gender	string
	Address string
	City template.HTML
	Phone string
	Image template.HTML
	Openings template.HTML
	Specialty string
}

var db *sql.DB
var err error
var tmpl1 *template.Template
var tmpl2 *template.Template
const PORT = 80

func check(e error) {
    if e != nil {
        panic(e)
    }
}


func mainPageHandler(w http.ResponseWriter, r *http.Request) {
	dat, err := ioutil.ReadFile("./html/index.html")
	check(err)
	fmt.Fprintf(w,string(dat))
}

func buildQuery(values url.Values) string {
		queryString := " WHERE "
		for k := range values {
			if values[k][0] != "" {
					if (k == "gender" && values[k][0] == "both") || (k == "specialty" && values[k][0] == "all") {
						continue
					}
					queryString = queryString + k + "='" + values[k][0] + "' AND "
			}

		}
		if values["gender"][0] == "both" && values["first_name"][0] == ""  && values["last_name"][0] ==  "" && values["email"][0] == ""  && values["address"][0] == ""  && values["city"][0] == "" && values["phone"][0] == ""  && values["specialty"][0] == "" {
				return ""
		}
		if values["gender"][0] == "" && values["first_name"][0] == ""  && values["last_name"][0] ==  "" && values["email"][0] == ""  && values["address"][0] == ""  && values["city"][0] == "" && values["phone"][0] == ""  && values["specialty"][0] == "all" {
				return ""
		}
		return queryString[:len(queryString)-5]
}

func insertImageAndCity(docs []Doctor) []Doctor {
	for i, element := range docs {
		if docs[i].Id == "N/A" {
			docs[i].Image = "<img alt=\"Missing\" src=\"" + element.Image + "\" />"
		} else {
			docs[i].Image = "<img alt=\"Missing\" src=\"" + element.Image + "\" />"
			docs[i].City = "<a href=\"https://www.google.com/maps?q=" + element.City + "\" target=\"_blank\">" + element.City + "</a>"
			docs[i].Email = "<a href=\"mailto:"  + element.Email + "?Subject=Dentist%20appointment\" target=\"_top\">" + element.Email + "</a>"
			docs[i].Openings = "<a href=\"/dentist?id=" + element.Id + "\">Click to view</a>"
		}
  }
	return docs
}

func insertDentistImageAndCity(docs []Doctor) []Doctor {
	for i, element := range docs {
		docs[i].Image = "<img alt=\"Missing\" src=\"" + element.Image + "\" />"
		docs[i].City = "<a href=\"https://www.google.com/maps?q=" + element.City + "\" target=\"_blank\">" + element.City + "</a>"
		docs[i].Email = "<a href=\"mailto:"  + element.Email + "?Subject=Dentist%20appointment\" target=\"_top\">" + element.Email + "</a>"
		docs[i].Openings = template.HTML(strings.Replace(string(docs[i].Openings), ",", "<br>", -1))
  }
	return docs
}

func searchHandler(w http.ResponseWriter, r *http.Request) {
	var Docs []Doctor
	baseQuery := "SELECT id, first_name, last_name, email, gender, address, city, phone, openings, specialty, image FROM enigma"
	r.ParseForm()
	rows, err := db.Query(baseQuery + buildQuery(r.Form))
	check(err)
	var newDoc Doctor
 	for rows.Next() {
        err = rows.Scan(&newDoc.Id, &newDoc.Firstname, &newDoc.Lastname, &newDoc.Email,
							&newDoc.Gender, &newDoc.Address, &newDoc.City, &newDoc.Phone,
							&newDoc.Openings, &newDoc.Specialty, &newDoc.Image)
				check(err)
				Docs = append(Docs, newDoc)
  }
	if len(Docs) == 0 {
		tmpl1.Execute(w, insertImageAndCity([]Doctor{Doctor{Id: "N/A",
																												Firstname: "Not found",
																												Lastname: "Not found",
																												Email: "Not found",
																												Gender: "Not found",
																												Address: "Not found",
																												City: "Not found",
																												Phone: "Not found",
																												Image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABGdBTUEAAK/INwWK6QAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAHdSURBVDjLpZNraxpBFIb3a0ggISmmNISWXmOboKihxpgUNGWNSpvaS6RpKL3Ry//Mh1wgf6PElaCyzq67O09nVjdVlJbSDy8Lw77PmfecMwZg/I/GDw3DCo8HCkZl/RlgGA0e3Yfv7+DbAfLrW+SXOvLTG+SHV/gPbuMZRnsyIDL/OASziMxkkKkUQTJJsLaGn8/iHz6nd+8mQv87Ahg2H9Th/BxZqxEkEgSrq/iVCvLsDK9awtvfxb2zjD2ARID+lVVlbabTgWYTv1rFL5fBUtHbbeTJCb3EQ3ovCnRC6xAgzJtOE+ztheYIEkqbFaS3vY2zuIj77AmtYYDusPy8/zuvunJkDKXM7tYWTiyGWFjAqeQnAD6+7ueNx/FLpRGAru7mcoj5ebqzszil7DggeF/DX1nBN82rzPqrzbRayIsLhJqMPT2N83Sdy2GApwFqRN7jFPL0tF+10cDd3MTZ2AjNUkGCoyO6y9cRxfQowFUbpufr1ct4ZoHg+Dg067zduTmEbq4yi/UkYidDe+kaTcP4ObJIajksPd/eyx3c+N2rvPbMDPbUFPZSLKzcGjKPrbJaDsu+dQO3msfZzeGY2TCvKGYQhdSYeeJjUt21dIcjXQ7U7Kv599f4j/oF55W4g/2e3b8AAAAASUVORK5CYII=",
																												Openings: "Not found",
																												Specialty: "Not found"}}))
		return
	}
	tmpl1.Execute(w, insertImageAndCity(Docs))
}



func dentistHandler(w http.ResponseWriter, r *http.Request) {
	var Docs []Doctor
	baseQuery := "SELECT id, first_name, last_name, email, gender, address, city, phone, openings, specialty, image FROM enigma"
	r.ParseForm()
	rows, err := db.Query(baseQuery + " WHERE id ='" + r.Form["id"][0] + "'")
	check(err)
	var newDoc Doctor
 	for rows.Next() {
        err = rows.Scan(&newDoc.Id, &newDoc.Firstname, &newDoc.Lastname, &newDoc.Email,
							&newDoc.Gender, &newDoc.Address, &newDoc.City, &newDoc.Phone,
							&newDoc.Openings, &newDoc.Specialty, &newDoc.Image)
				check(err)
				Docs = append(Docs, newDoc)
  }
	tmpl2.Execute(w, insertDentistImageAndCity(Docs))
}


func main() {
    tmpl1 = template.Must(template.ParseFiles("./html/search.html"))
		tmpl2 = template.Must(template.ParseFiles("./html/dentist.html"))
    db, err = sql.Open("sqlite3", "./enigma.db")
    check(err)

    http.HandleFunc("/", mainPageHandler)
    http.HandleFunc("/search", searchHandler)
    http.HandleFunc("/dentist", dentistHandler)

		fmt.Println("Server is running...")

    fs := http.FileServer(http.Dir("./html/static"))
    http.Handle("/static/", http.StripPrefix("/static", fs))


    err = http.ListenAndServe(":80", nil)
    if err != nil {
        log.Fatal("ListenAndServe: ", err)
    }
    db.Close()
}

